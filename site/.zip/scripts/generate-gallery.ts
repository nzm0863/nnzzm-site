import fs from "fs";
import path from "path";

const galleryRoot = path.join(process.cwd(), "public", "images", "gallery");
const outputFile = path.join(process.cwd(), "src", "content", "gallery.ts");

const titleMap: Record<string, string> = {
  lala: "ララ・サタリン・デビルーク",
  yami: "金色の闇",
  momo: "モモ・ベリア・デビルーク",
  mea: "黒咲芽亜",
  mikan: "結城美柑",
  // original
  "game-charactor": "ゲームキャラクター(試作)",
};

const setTitleMap: Record<string, string> = {
  normal: "通常衣装",
  miko: "巫女",
  shower: "シャワー",
  cheerleader: "チアリーダー",
  r18_shower: "R18シャワー",
  beach:"ビーチ",
  date:"デート",
  pajamas:"パジャマ",
  forest:"森",
  camisole:"キャミソール",
  r18_camisole:"R18キャミソール",
  r18_sports:"R18体操服",
  cosplay:"いろんなコスプレ",
  whiteT:"白T"
};

const slugify = (category: string, character: string) =>
  `${category.toLowerCase()}-${character}`;

const categories = fs.readdirSync(galleryRoot).sort((a, b) => {
  if (a === "original") return 1;
  if (b === "original") return -1;

  return a.localeCompare(b);
});

const characterOrder = Object.keys(titleMap);
const galleries = categories.flatMap((category) => {
  const categoryPath = path.join(galleryRoot, category);

  if (!fs.statSync(categoryPath).isDirectory()) return [];

  const characters = fs.readdirSync(categoryPath).sort((a, b) => {
    const indexA = characterOrder.indexOf(a);
    const indexB = characterOrder.indexOf(b);

    if (indexA !== -1 && indexB !== -1) {
      return indexA - indexB;
    }

    if (indexA !== -1) return -1;
    if (indexB !== -1) return 1;

    return a.localeCompare(b);
  });

  return characters.map((character) => {
    const characterPath = path.join(categoryPath, character);

    const sets = fs
      .readdirSync(characterPath)
      .filter((set) => fs.statSync(path.join(characterPath, set)).isDirectory())
      .map((set) => {
        const setPath = path.join(characterPath, set);

        const images = fs
          .readdirSync(setPath)
          .filter((file) => file.endsWith(".webp") && file !== "cover.webp")
          .sort();

        return {
          slug: set,
          title: setTitleMap[set] ?? set,
          cover: `/images/gallery/${category}/${character}/${set}/cover.webp`,
          images: images.map(
            (image) =>
              `/images/gallery/${category}/${character}/${set}/${image}`,
          ),
          isR18: set.toLowerCase().startsWith("r18_"),
        };
      });

    return {
      slug: slugify(category, character),
      category,
      title: titleMap[character] ?? character,
      sets,
    };
  });
});

const output = `// 自動生成ファイル。編集しないでください。

export type GallerySet = {
  slug: string;
  title: string;
  cover: string;
  images: string[];
  isR18: boolean;
};

export type Gallery = {
  slug: string;
  category: string;
  title: string;
  sets: GallerySet[];
};

export const galleries: Gallery[] = ${JSON.stringify(galleries, null, 2)};
`;

fs.writeFileSync(outputFile, output);

console.log("✅ gallery.ts generated!");
console.log("Characters:", galleries.length);
